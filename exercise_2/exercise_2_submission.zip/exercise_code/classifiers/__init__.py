from exercise_code.classifiers.fc_net import *
